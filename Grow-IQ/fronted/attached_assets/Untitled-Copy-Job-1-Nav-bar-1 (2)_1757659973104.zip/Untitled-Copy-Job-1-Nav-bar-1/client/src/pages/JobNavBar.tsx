import React from "react";
import { NavigationHeader } from "@/components/ui/navigation-header";
import { JobListSection } from "./sections/JobListSection";
import { Home, BarChart3, User, Settings, LogIn, Briefcase } from "lucide-react";
import { usePageTransition } from "@/hooks/usePageTransition";
import { BounceButton } from "@/components/ui/bounce-animation";

export const JobNavBar = (): JSX.Element => {
  const { location, navigateWithBubbles } = usePageTransition();

  const navigationItems = [
    {
      icon: Home,
      route: "/",
      label: "Home",
      testId: "nav-home"
    },
    {
      icon: Briefcase,
      route: "/",
      label: "Jobs",
      testId: "nav-jobs"
    },
    {
      icon: BarChart3,
      route: "/dashboard",
      label: "Dashboard",
      testId: "nav-dashboard"
    },
    {
      icon: User,
      route: "/profile",
      label: "Profile",
      testId: "nav-profile"
    },
    {
      icon: Settings,
      route: "/settings",
      label: "Settings",
      testId: "nav-settings"
    },
    {
      icon: LogIn,
      route: "/login",
      label: "Login",
      testId: "nav-login"
    },
  ];

  const handleNavigation = (route: string) => {
    navigateWithBubbles(route);
  };

  return (
    <div className="bg-neutral-100 w-screen min-h-screen flex flex-col">
      <NavigationHeader title="Jobs" showBackButton={false} />

      <div className="flex flex-1 min-h-0">
        <nav className="w-[102px] bg-gradient-to-b from-[#673ab7] to-[#5e35b1] rounded-r-[64px] flex flex-col items-center py-8 relative z-10 shadow-2xl sticky top-0 h-screen">
          {/* Logo section - perfectly centered */}
          <div className="mb-10 flex items-center justify-center">
            <div className="w-14 h-14 bg-gradient-to-br from-white to-[#00bfa6] rounded-full flex items-center justify-center shadow-lg">
              <Briefcase size={26} className="text-[#673ab7]" />
            </div>
          </div>
          
          {/* Navigation items - centered and evenly spaced */}
          <div className="flex flex-col items-center justify-center gap-6 flex-1">
            {navigationItems.map((item, index) => {
              const Icon = item.icon;
              const isActive = location === item.route;
              return (
                <BounceButton
                  key={index}
                  data-testid={item.testId}
                  onClick={() => handleNavigation(item.route)}
                  className={`
                    flex items-center justify-center w-14 h-14 rounded-2xl
                    transition-all duration-300 ease-out
                    ${isActive 
                      ? 'bg-white text-[#673ab7] shadow-2xl transform scale-110' 
                      : 'text-white/90 hover:bg-white/20 hover:scale-105 hover:text-white'
                    }
                  `}
                  title={item.label}
                  variant="ghost"
                  size="sm"
                  bounceOnClick={true}
                >
                  <Icon size={24} strokeWidth={isActive ? 2.5 : 2} />
                </BounceButton>
              );
            })}
          </div>
          
          {/* Decorative elements - perfectly positioned */}
          <div className="absolute top-6 right-3 w-2.5 h-2.5 bg-[#00bfa6] rounded-full animate-pulse shadow-lg" />
          <div className="absolute bottom-6 right-4 w-1.5 h-1.5 bg-white/60 rounded-full animate-bounce" />
        </nav>

        {/* Main Content Area - properly aligned */}
        <main className="flex-1 bg-white shadow-inner">
          <JobListSection />
        </main>
      </div>
    </div>
  );
};
